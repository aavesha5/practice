package com.java.lms;

import java.sql.Date;

public class Employ 
{
	private int empid;
	private String name;
	private String email;
	private String mobNo;
	private Date date;
	private String dept;
	private int managerId;
	private int leaveAvail;
	
	public Employ() {
		
	}
	
	public Employ(int empid, String name, String email, String mobNo, Date date, String dept, int managerId,
			int leaveAvail) {
		
		this.empid = empid;
		this.name = name;
		this.email = email;
		this.mobNo = mobNo;
		this.date = date;
		this.dept = dept;
		this.managerId = managerId;
		this.leaveAvail = leaveAvail;
	}
	
	public int getEmpid() {
		return empid;
	}
	public void setEmpid(int empid) {
		this.empid = empid;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getMobNo() {
		return mobNo;
	}
	public void setMobNo(String mobNo) {
		this.mobNo = mobNo;
	}
	public Date getDate() {
		return date;
	}
	public void setDate(Date date) {
		this.date = date;
	}
	public String getDept() {
		return dept;
	}
	public void setDept(String dept) {
		this.dept = dept;
	}
	public int getManagerId() {
		return managerId;
	}
	public void setManagerId(int managerId) {
		this.managerId = managerId;
	}
	public int getLeaveAvail() {
		return leaveAvail;
	}
	public void setLeaveAvail(int leaveAvail) {
		this.leaveAvail = leaveAvail;
	}
	
	@Override
	public String toString() {
		return "Employ [empid=" + empid + ", name=" + name + ", email=" + email + ", mobNo=" + mobNo + ", date=" + date
				+ ", dept=" + dept + ", managerId=" + managerId + ", leaveAvail=" + leaveAvail + "]";
	}
}
