package com.java.Dao;

import java.sql.SQLException;
import java.util.List;

import com.java.lms.Employ;
import com.java.lms.Leave;

public interface EmployDAO 
{
	List<Employ> showEmployDao() throws ClassNotFoundException, SQLException ;
	Employ searchEmployDao(int empno) throws ClassNotFoundException, SQLException ;
	
	String applyLeave (Leave leave) throws ClassNotFoundException, SQLException;
	
	
	
	
	
	
}
