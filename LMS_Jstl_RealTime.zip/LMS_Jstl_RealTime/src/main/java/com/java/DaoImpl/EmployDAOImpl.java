package com.java.DaoImpl;
import java.sql.Connection;
import java.util.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

import com.java.Dao.ConnectionHelper;
import com.java.Dao.EmployDAO;
import com.java.lms.Employ;
import com.java.lms.Leave;
import com.java.lms.LeaveStatus;
import com.java.lms.LeaveType;
import com.sun.research.ws.wadl.Request;

public class EmployDAOImpl implements EmployDAO
{
	Connection connection;
	PreparedStatement pst;
	
	public int noOfDaysLeaves(Leave leave)
	{
		int noOfDays;
		  long ms = leave.getEdate().getTime() - leave.getSdate().getTime();
	        System.out.println(ms);
	        noOfDays = (int)( (ms)/(1000 * 60 * 60 * 24));
	        return ++noOfDays;
	}
	
	public java.sql.Date convertToSql(String date) throws ParseException
	{
		SimpleDateFormat sdf=new SimpleDateFormat("yyyy-MM-dd");
		java.util.Date utilDate =sdf.parse(date);
		java.sql.Date sqlDate = new java.sql.Date(utilDate.getTime());
		return sqlDate;
	}
	
	@Override
	public List<Employ> showEmployDao() throws  ClassNotFoundException,SQLException 
	{
		connection = ConnectionHelper.getConnection();
		String cmd = "select * from Employee";
		pst=connection.prepareStatement(cmd);
ResultSet rs = pst.executeQuery();
		
		List <Employ> employList = new ArrayList<Employ>();
		Employ employ = null;
		while(rs.next())
		{
			employ = new Employ();
			employ.setEmpid(rs.getInt("emp_id"));
			employ.setName(rs.getString("emp_name"));
			employ.setEmail(rs.getString("emp_mail"));
			employ.setMobNo(rs.getString("emp_mob_no"));
			employ.setDate(rs.getDate("emp_dt_join"));
			employ.setDept(rs.getString("emp_dept"));
			employ.setManagerId(rs.getInt("emp_manager_id"));
			employ.setLeaveAvail(rs.getInt("emp_avail_leave_bal"));
			employList.add(employ);
		}
		connection.close();
		pst.close();
		return employList;
	}
	
	@Override
	public Employ searchEmployDao(int empid) throws ClassNotFoundException, SQLException 
	{
		connection = ConnectionHelper.getConnection();
		String cmd = "select * from Employee where emp_id = ?";
		pst = connection.prepareStatement(cmd);
		pst.setInt(1, empid);
		ResultSet rs = pst.executeQuery();
		
		Employ employ = null;
		if(rs.next())
		{
			employ = new Employ();
			employ.setEmpid(rs.getInt("emp_id"));
			employ.setName(rs.getString("emp_name"));
			employ.setEmail(rs.getString("emp_mail"));
			employ.setMobNo(rs.getString("emp_mob_no"));
			employ.setDate(rs.getDate("emp_dt_join"));
			employ.setDept(rs.getString("emp_dept"));
			employ.setManagerId(rs.getInt("emp_manager_id"));
			employ.setLeaveAvail(rs.getInt("emp_avail_leave_bal"));
		}
		connection.close();
		pst.close();
		return employ;
	}

	@Override
	public String applyLeave(Leave leave) throws ClassNotFoundException, SQLException 
	{		
		int noOfDays = noOfDaysLeaves(leave);
		leave.setNoOfDays(noOfDays);

		leave.setLeaveType(LeaveType.EL);
		leave.setLeaveStatus(LeaveStatus.PENDING);
		
		connection = ConnectionHelper.getConnection();
		String cmd = "Insert into leave_history (leave_no_of_days ,"
				+ "emp_id ,leave_start_date ,leave_end_date ,LEAVE_TYPE, leave_status , leave_reason)values(?,?,?,?,?,?,?)";
		
		pst = connection.prepareStatement(cmd);
		pst.setInt(1, noOfDays);
		pst.setInt(2, leave.getEmpid());
		pst.setDate(3, leave.getSdate());
		pst.setDate(4, leave.getEdate());
		pst.setString(5, leave.getLeaveType().toString());
		pst.setString(6, leave.getLeaveStatus().toString());
		pst.setString(7, leave.getLeaveReason());
		
		pst.executeUpdate();
		System.out.println("Leave APplied");
		return "Leave applied successfully....!";
	}
}